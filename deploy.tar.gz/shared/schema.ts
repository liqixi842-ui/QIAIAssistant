import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(), // 真实姓名
  nickname: text("nickname"), // 花名
  role: text("role").notNull().default("业务"), // 角色：主管、总监、经理、业务、后勤
  position: text("position"), // 职位
  team: text("team"), // 团队
  supervisorId: varchar("supervisor_id"), // 上级ID
  phone: integer("phone").default(0), // 手机数量
  computer: integer("computer").default(0), // 电脑数量
  charger: integer("charger").default(0), // 充电器数量
  dormitory: text("dormitory"), // 宿舍
  joinDate: text("join_date"), // 入职日期
  wave: text("wave"), // 波数
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const customers = pgTable("customers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name"), // 姓名（可选）
  phone: text("phone").notNull(), // 电话后四位（必填，4位数字）
  wechat: text("wechat"), // 微信
  channel: text("channel"), // 渠道
  date: text("date"), // 日期
  assistant: text("assistant"), // 接粉助理
  group: text("group"), // 群
  age: text("age"), // 年龄
  location: text("location"), // 地址
  stockAge: text("stock_age"), // 股龄
  profitLoss: text("profit_loss"), // 盈亏
  stockSelection: text("stock_selection"), // 选股方式
  tradingHabit: text("trading_habit"), // 操作习惯
  income: text("income"), // 工作收入
  family: text("family"), // 家庭情况
  occupation: text("occupation"), // 职业
  hobbies: text("hobbies"), // 兴趣爱好
  groupPurpose: text("group_purpose"), // 进群目的
  other: text("other"), // 其他
  stage: text("stage").default("初次接触"), // 阶段
  lastContact: text("last_contact"), // 最后联系时间
  tags: jsonb("tags").$type<Array<{label: string; type: string}>>(), // 标签数组（结构化对象）
  createdBy: varchar("created_by"), // 创建者（业务员）ID
  aiAnalysis: text("ai_analysis"), // AI分析结果
  recommendedScript: text("recommended_script"), // AI生成的推荐话术
  
  // 国际化字段
  language: text("language"), // 语言（中文、英语、日语等）
  country: text("country"), // 国家（现在所在的国家）
  
  // 互动数据字段
  lastReplyAt: text("last_reply_at"), // 客户最后回复时间
  conversationCount: integer("conversation_count").default(0), // 对话次数（我们发送的消息数）
  replyCount: integer("reply_count").default(0), // 回复次数（客户回复的消息数）
  
  // 封锁状态
  blocked: integer("blocked").default(0), // 0=正常 1=已封锁
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
}).extend({
  phone: z.string()
    .min(4, "手机后四位必须是4位数字")
    .max(4, "手机后四位必须是4位数字")
    .regex(/^\d{4}$/, "手机后四位必须是4位数字"),
  blocked: z.number().optional()
});

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull(), // 关联的客户ID
  title: text("title").notNull(), // 任务标题
  description: text("description"), // 任务描述
  guidanceSteps: jsonb("guidance_steps").$type<string[]>(), // 完成任务的详细步骤
  script: text("script"), // 推荐使用的话术
  status: text("status").notNull().default("pending"), // 任务状态：active、pending、completed
  assignedAgentId: varchar("assigned_agent_id"), // 分配的业务员ID
  createdBy: varchar("created_by"), // 创建者ID (可以是AI或用户)
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`), // 创建时间
  dueAt: text("due_at"), // 截止时间
  completedAt: text("completed_at"), // 完成时间
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  chatId: varchar("chat_id").notNull(), // 聊天室ID（用于隔离不同对话）
  senderId: varchar("sender_id").notNull(), // 发送者用户ID
  senderName: text("sender_name").notNull(), // 发送者昵称
  content: text("content").notNull(), // 消息内容
  timestamp: text("timestamp").notNull().default(sql`CURRENT_TIMESTAMP`), // 时间戳
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// 学习资料表
export const learningMaterials = pgTable("learning_materials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(), // 文件标题
  categoryId: text("category_id").notNull(), // 分类ID
  fileType: text("file_type").notNull(), // 文件类型
  fileSize: integer("file_size").notNull(), // 文件大小（字节）
  fileUrl: text("file_url").notNull(), // 文件URL（存储路径）
  uploadDate: text("upload_date").notNull().default(sql`CURRENT_TIMESTAMP`), // 上传日期
  uploadedBy: varchar("uploaded_by"), // 上传者ID
});

export const insertLearningMaterialSchema = createInsertSchema(learningMaterials).omit({
  id: true,
  uploadDate: true,
});

export type InsertLearningMaterial = z.infer<typeof insertLearningMaterialSchema>;
export type LearningMaterial = typeof learningMaterials.$inferSelect;

// 学习资料分类表
export const scriptCategories = pgTable("script_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // 分类名称
  parentId: varchar("parent_id"), // 父分类ID（null表示顶级分类）
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`), // 创建时间
  createdBy: varchar("created_by"), // 创建者ID
});

export const insertScriptCategorySchema = createInsertSchema(scriptCategories).omit({
  id: true,
  createdAt: true,
});

export type InsertScriptCategory = z.infer<typeof insertScriptCategorySchema>;
export type ScriptCategory = typeof scriptCategories.$inferSelect;

// 聊天室表
export const chats = pgTable("chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // 类型：direct（私聊）或 group（群聊）
  name: text("name"), // 聊天室名称（私聊为null，群聊有名称）
  createdBy: varchar("created_by").notNull(), // 创建者用户ID
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`), // 创建时间
});

export const insertChatSchema = createInsertSchema(chats).omit({
  id: true,
  createdAt: true,
});

export type InsertChat = z.infer<typeof insertChatSchema>;
export type Chat = typeof chats.$inferSelect;

// 聊天室成员表
export const chatParticipants = pgTable("chat_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  chatId: varchar("chat_id").notNull(), // 聊天室ID
  userId: varchar("user_id").notNull(), // 用户ID
  role: text("role").notNull().default("member"), // 角色：owner（创建者）、admin（管理员）、member（成员）
  joinedAt: text("joined_at").notNull().default(sql`CURRENT_TIMESTAMP`), // 加入时间
  lastReadAt: text("last_read_at"), // 最后已读时间（用于未读消息统计）
});

export const insertChatParticipantSchema = createInsertSchema(chatParticipants).omit({
  id: true,
  joinedAt: true,
});

export type InsertChatParticipant = z.infer<typeof insertChatParticipantSchema>;
export type ChatParticipant = typeof chatParticipants.$inferSelect;

// Session表（connect-pg-simple自动创建，这里定义以防止被删除）
export const session = pgTable("session", {
  sid: varchar("sid").primaryKey(), // Session ID
  sess: jsonb("sess").notNull(), // Session数据
  expire: timestamp("expire").notNull(), // 过期时间
});

export type Session = typeof session.$inferSelect;

// 审计日志表 - 记录所有重要操作
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  action: text("action").notNull(), // 操作类型：update_supervisor, update_password, delete_user, register, login, logout等
  targetUserId: varchar("target_user_id"), // 被操作的用户ID（如果适用）
  targetUsername: text("target_username"), // 被操作的用户名（如果适用）
  operatorId: varchar("operator_id"), // 执行操作的用户ID
  operatorUsername: text("operator_username"), // 执行操作的用户名
  operatorRole: text("operator_role"), // 执行操作的用户角色
  details: jsonb("details").$type<Record<string, any>>(), // 详细信息（JSON格式，比如：{old: "7", new: "8"}）
  ipAddress: text("ip_address"), // IP地址
  userAgent: text("user_agent"), // 浏览器信息
  timestamp: text("timestamp").notNull().default(sql`CURRENT_TIMESTAMP`), // 时间戳
  success: integer("success").notNull().default(1), // 是否成功：1成功，0失败
  errorMessage: text("error_message"), // 错误信息（如果失败）
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  timestamp: true,
});

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;

// 反馈表 - 用户投诉建议
export const feedbacks = pgTable("feedbacks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(), // 标题
  content: text("content").notNull(), // 内容
  submitterId: varchar("submitter_id").notNull(), // 提交者ID
  submitterName: text("submitter_name").notNull(), // 提交者名称（冗余字段，方便查询）
  isResolved: integer("is_resolved").notNull().default(0), // 是否已处理：0未处理，1已处理
  submittedAt: text("submitted_at").notNull().default(sql`CURRENT_TIMESTAMP`), // 提交时间
  resolvedAt: text("resolved_at"), // 处理时间
  resolvedBy: varchar("resolved_by"), // 处理者ID
});

export const insertFeedbackSchema = createInsertSchema(feedbacks).omit({
  id: true,
  submittedAt: true,
});

export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Feedback = typeof feedbacks.$inferSelect;
