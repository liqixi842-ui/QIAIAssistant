import RegisterPage from '../../pages/RegisterPage';

export default function RegisterPageExample() {
  return <RegisterPage />;
}
