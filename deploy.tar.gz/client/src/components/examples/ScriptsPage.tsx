import ScriptsPage from '../../pages/ScriptsPage';

export default function ScriptsPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <ScriptsPage />
    </div>
  );
}
