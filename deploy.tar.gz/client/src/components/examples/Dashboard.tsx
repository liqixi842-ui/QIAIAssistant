import Dashboard from '../../pages/Dashboard';

export default function DashboardExample() {
  return (
    <div className="p-8 max-w-7xl">
      <Dashboard />
    </div>
  );
}
