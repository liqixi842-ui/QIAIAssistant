import KanbanPage from '../../pages/KanbanPage';

export default function KanbanPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <KanbanPage />
    </div>
  );
}
