import FeedbackPage from '../../pages/FeedbackPage';

export default function FeedbackPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <FeedbackPage />
    </div>
  );
}
