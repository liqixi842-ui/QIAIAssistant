import AIChatPage from '../../pages/AIChatPage';

export default function AIChatPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <AIChatPage />
    </div>
  );
}
