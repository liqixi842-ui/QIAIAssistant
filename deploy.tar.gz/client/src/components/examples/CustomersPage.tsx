import CustomersPage from '../../pages/CustomersPage';

export default function CustomersPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <CustomersPage />
    </div>
  );
}
