import ChatPage from '../../pages/ChatPage';

export default function ChatPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <ChatPage />
    </div>
  );
}
