import TasksPage from '../../pages/TasksPage';

export default function TasksPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <TasksPage />
    </div>
  );
}
