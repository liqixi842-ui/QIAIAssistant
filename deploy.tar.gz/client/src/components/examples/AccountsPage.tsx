import AccountsPage from '../../pages/AccountsPage';

export default function AccountsPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <AccountsPage />
    </div>
  );
}
