import ReportsPage from '../../pages/ReportsPage';

export default function ReportsPageExample() {
  return (
    <div className="p-8 max-w-7xl">
      <ReportsPage />
    </div>
  );
}
